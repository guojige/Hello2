#ifndef __DRAW_H__
#define __DRAW_H__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "game.h"
#include "color.h"

extern void draw(game_t *game);


#endif
