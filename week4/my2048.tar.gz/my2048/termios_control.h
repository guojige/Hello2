#ifndef __TERMIOS_CONTROL_H__
#define __TERMIOS_CONTROL_H__

#include <termios.h> //操作终端
#include <stdio.h>
#include <unistd.h>
#include <assert.h>
#include <string.h>

char my_getch(void);


#endif
