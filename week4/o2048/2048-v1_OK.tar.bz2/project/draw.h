#ifndef __DRAW_H__
#define __DRAW_H__

#include <stdio.h>

void draw_form(int box[]);

#endif
