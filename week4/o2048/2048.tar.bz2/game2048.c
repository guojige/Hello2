#include <stdio.h>
#include <termios.h> //�����ն�
#include <stdio.h>
#include <unistd.h>
#include <assert.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>

#define SPACE()         printf("       ")
#define RED(val)        printf("\033[31;1m%4d   \033[0m", val)
#define GREEN(val)      printf("\033[32;1m%4d   \033[0m", val)
#define YELLOW(val)     printf("\033[33;1m%4d   \033[0m", val)
#define BLUE(val)       printf("\033[34;1m%4d   \033[0m", val)
#define PURPLE(val)     printf("\033[35;1m%4d   \033[0m", val)
#define DEEPGREEN(val)  printf("\033[36;1m%4d   \033[0m", val)

void print_number(int val);
char my_getch(void);
int  get_command(void);
void draw(int box[]);
void update_box(int box[], int dir);
void update(int box[], int dir);
void merge(int box16[], int dir);
int random_2or4(void);
void update(int box[], int dir);

int pos = 0;

int main()
{
	int box[16] = {0};
   	int dir;
	srand(time(NULL));
	 
	draw(box);
	while(1)
	{
        	dir = get_command();	
        	if(dir == 0)
            		return 0;
        	update(box, dir);
        	draw(box);
    	}
	return 0;
}

void update_box(int box[], int dir)
{
       
        switch(dir){
                case 1:
					if(pos-4>=0)
					{
                        box[pos-4] = box[pos];
                        box[pos] = 0;
                        pos -= 4;
					}
                   break;
                case 2:
					if(pos+4 <= 15)
					{
                        box[pos+4] = box[pos];
                        box[pos] = 0;
                        pos += 4;
					}
                   break;
				case 3:
					if(pos % 4 != 0)
					{
						box[pos-1] = box[pos];
						box[pos] = 0;
						pos -= 1;
					}
					break;
				case 4:
					if( (pos+1) % 4 != 0)
					{
						box[pos+1] = box[pos];
						box[pos] = 0;
						pos += 1;
					}
					break;
                default:
                   break;
                      
        }
}



void print_number(int val)
{
        switch(val){
                case 0:
                   SPACE();
                   break;
                case 2:
                case 2048:
                   RED(val);
                   break;
                case 4:
                case 1024:
                   GREEN(val);
                   break;
                case 8:
                case 512:
                   YELLOW(val);
                   break;
                case 16:
                case 256:
                   BLUE(val);
                   break;
                case 32:
                case 128:
                   PURPLE(val);
                   break;
                case 64:
                   DEEPGREEN(val);
                   break;
                default:
                   break;
        }
}


char my_getch(void) 
{
        int c=0;  int res=0;
        struct termios org_opts, new_opts;
        //�����ն�ԭ������
        res=tcgetattr(STDIN_FILENO, &org_opts);
        assert(res==0);
        //���������ն˲���
        memcpy(&new_opts, &org_opts, sizeof(new_opts));
        new_opts.c_lflag &= ~(ICANON | ECHO | ECHOE | ECHOK | ECHONL | ECHOPRT | ECHOKE | ICRNL);
        tcsetattr(STDIN_FILENO, TCSANOW, &new_opts);
        c=getchar();////������ȡ����jian  
        //�ָ��ж�����
        res=tcsetattr(STDIN_FILENO, TCSANOW, &org_opts);
		assert(res==0);
        return c; 
}

/*
	0:QUIT      27 \n
	1:UP, 		W
	2:DOWN, 	S
	3:LEFT,		A
	4:RIGHT, 	D
*/

int  get_command(void)
{
	int dir;  
	char ch = my_getch();
	printf("%d\n", ch);
    	if(ch == 27 || ch == '\n')
	{	
		return 0;
    	}
	else if(ch == 'w' || ch == 'W')
	{
		return 1;
	}
	else if(ch == 's' || ch == 'S')
	{
		return 2;
	}
	else if(ch == 'a' || ch == 'A')
	{
		return 3;
	}
	else if(ch == 'd' || ch == 'D')
	{
		return 4;
	}
	else 
	{
		return -1;
	}
	
}


void draw(int box[])
{
        int i, j;

        printf("\033[2J");
        printf("\033[?25l");
 

        for(i=0; i<4;i++){
                printf("\033[30;1m---------------------------------\n");
                printf("\033[30;1m|       |       |       |       |\n");
                for(j=0; j<4; j++){
                        printf("\033[30;1m|");
                        print_number(box[4*i+j]);
                }
                printf("\033[30;1m|\n");
                printf("\033[30;1m|       |       |       |       |\n");
        }
        printf("\033[30;1m---------------------------------\n");
}


int random_2or4(void)
{
   int val = rand() % 4;
   return val > 2 ? 4 : 2;
}

int find_postion(int box[])
{
   int i, pos = -1;
   int count = 0;
   int empty[16]={0};
   for(i=0; i<16; i++)
      if(box[i] == 0) // count empty position 
         empty[count++] = i;

   if(count == 0)
      return -1; // game over
   
   pos = empty[rand()%count];
   return pos;
}

void merge(int box16[], int dir)
{
   int box[4][4] = {0};
   int i, j;
   int deep;
   int moved=-1, mline = 0;
   
   for(i=0; i<4; i++)
      for(j=0; j<4; j++)
         box[i][j] = box16[i*4+j];

   if(dir == 4){
      for(i=0; i<4; i++){  // row
         deep = 3;
         mline = 0;
         for(j=3; j>=0; j--){
            if(box[i][j] != 0){
               box[i][deep] = box[i][j];  // move to right
               if(deep != j)
                  box[i][j] = 0;
               if(deep < 3 && mline == 0 && box[i][deep] == box[i][deep+1]){
                 
                  box[i][deep+1] *= 2;
                  box[i][deep] = 0;
                  mline = 1;
               }
               else
                  deep--;
            }
         }

      }
   }

   if(dir == 3){
      for(i=0; i<4; i++){  // row
         deep = 0;
         mline = 0;
         for(j=0; j<4; j++){
            if(box[i][j] != 0){
               box[i][deep] = box[i][j];  // move to left
               if(deep != j)
                  box[i][j] = 0;
               if(deep > 0 && mline == 0 && box[i][deep] == box[i][deep-1]){
                
                  box[i][deep-1] *= 2;
                  box[i][deep] = 0;
                  mline = 1;
               }
               else
                  deep++;
            }
         }
      }
   }

   if(dir == 1){
      for(j=0; j<4; j++){  // col
         deep = 0;
         mline = 0;
         for(i=0; i<4; i++){
            if(box[i][j] != 0){
               box[deep][j] = box[i][j];  // move to up
               if(deep != i)
                  box[i][j] = 0;
               if(deep > 0 && mline == 0 && box[deep][j] == box[deep-1][j]){
                
                  box[deep-1][j] *= 2;
                  box[deep][j] = 0;
                  mline = 1;
               }
               else
                  deep++;
            }
         }
      }
   }
   if(dir == 2){
      for(j=0; j<4; j++){  // row
         deep = 3;
         mline = 0;
         for(i=3; i>=0; i--){
            if(box[i][j] != 0){
               box[deep][j] = box[i][j];  // move to down
               if(deep != i)
                  box[i][j] = 0;
               if(deep < 3 && mline == 0 && box[deep][j] == box[deep+1][j]){
                 
                  box[deep+1][j] *= 2;
                  box[deep][j] = 0;
                  mline = 1;
               }
               else
                  deep--;
            }
         }
      }
   }
     
   for(i=0; i<4; i++)
      for(j=0; j<4; j++)
         if(box16[i*4+j] != box[i][j])
		 {
            box16[i*4+j] = box[i][j];  
            if(box16[i*4+j] == 2048)  // ��������ĳ��ֵ����2048��Ӯ��
			{
               printf("YOU WIN\n");
			   exit(0);  // �˳�����
			}
         }
}


void update(int box[], int dir)
{
   int newpos;  
   int randval;
   merge(box, dir);   //�ϲ�
   newpos = find_postion(box);  //Ѱ�ҿհ�0λ��
   if(newpos < 0)       //  ����Ҳ����հף���Ϸ����
   {
		printf("GAME OVER\n");
		exit(0);
   }
   randval = random_2or4();   // �������һ����2��4
   box[newpos] = randval;     // ��������ŵ��հ�λ��

}
