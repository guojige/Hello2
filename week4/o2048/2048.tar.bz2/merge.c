#include <stdio.h>

void move1(int box[])
{
	int empty = 3;
	int left = empty-1;
	while(empty)
	{
		while(empty > 0 && box[empty] != 0 )
		{
			empty--;
		}
		if(!empty)
			return ;
		left = empty - 1;
		while(left >=0 && box[left] == 0)
		{
			left--;
		}
		if(left<0)
			return ;
		box[empty] = box[left];
		box[left] = 0;
		empty--;
	}
}

void disp(int box[])
{
	int i;
	for(i=0; i<4; i++)
	{
		printf("%d	", box[i]);
	}
	puts("");
}

void merge(int box[])
{
	int right = 3;
	int left = right - 1;
	while(right > 0)
	{
		if(box[right] == box[left])
		{
			box[right] *= 2;
			box[left] = 0;
			return ;
		}
		else
		{
			right--;
			left--;
		}
	}
}

int main()
{
	int box[4] = {4, 2,  0, 2};	
	move1(box);
	disp(box);
	merge(box);
	disp(box);
	move1(box);
	disp(box);

	return 0;
}
