#include "confparser.h"


Config *init_config()
{
	Config *gconfig = (Config*)malloc(sizeof(Config));
	//if(NULL == config)
	memset(gconfig, 0, sizeof(Config));

	return gconfig;
}

void    load_config(Config *gconfig)
{
	
}


