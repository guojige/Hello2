#include "spider.h"
#include "confparser.h"

int main()
{

	//printf("hello,spider\n");
	Config *gconfig = init_config();
	load_config(gconfig);
	
	
	return 0;
}

